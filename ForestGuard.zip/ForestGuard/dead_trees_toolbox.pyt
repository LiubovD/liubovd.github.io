import arcpy
import os

class Toolbox(object):
    def __init__(self):
        """Define the toolbox (the name of the toolbox is the name of the
        .pyt file)."""
        self.label = "Dead Trees Detection Toolbox"
        self.alias = "DeadTrees"

        # List of tool classes associated with this toolbox
        self.tools = [DetectDeadTrees]

class DetectDeadTrees(object):
    def __init__(self):
        """Define the tool (tool name is the class name)."""
        self.label = "Detect Dead Trees"
        self.description = "Detects dead trees from aerial imagery using classification and filtering techniques"
        self.canRunInBackground = False

    def getParameterInfo(self):
        """Define parameter definitions"""
        params = []
        
        # Input raster parameter
        param0 = arcpy.Parameter(
            displayName="Input Aerial Image",
            name="input_raster",
            datatype="DERasterDataset",
            parameterType="Required",
            direction="Input")
        params.append(param0)
        
        # Forest mask parameter
        param1 = arcpy.Parameter(
            displayName="Forest Mask Layer",
            name="mask_layer",
            datatype="GPFeatureLayer",
            parameterType="Required",
            direction="Input")
        params.append(param1)
        
        # Output workspace
        param2 = arcpy.Parameter(
            displayName="Output Workspace",
            name="workspace",
            datatype="DEWorkspace",
            parameterType="Required",
            direction="Input")
        params.append(param2)
        
        # Number of classes
        param3 = arcpy.Parameter(
            displayName="Number of Classes for Classification",
            name="number_classes",
            datatype="GPLong",
            parameterType="Optional",
            direction="Input")
        param3.value = 10
        params.append(param3)
        
        # Minimum area threshold
        param4 = arcpy.Parameter(
            displayName="Minimum Tree Area (square meters)",
            name="min_area",
            datatype="GPDouble",
            parameterType="Optional",
            direction="Input")
        param4.value = 2.0
        params.append(param4)
        
        # Buffer distance
        param5 = arcpy.Parameter(
            displayName="Buffer Distance (meters)",
            name="buffer_distance",
            datatype="GPLinearUnit",
            parameterType="Optional",
            direction="Input")
        param5.value = "1 Meters"
        params.append(param5)
        
        # Minimum buffer area
        param6 = arcpy.Parameter(
            displayName="Minimum Buffer Area (square meters)",
            name="min_buffer_area",
            datatype="GPDouble",
            parameterType="Optional",
            direction="Input")
        param6.value = 80.0
        params.append(param6)
        
        # Output feature class
        param7 = arcpy.Parameter(
            displayName="Output Dead Trees Feature Class",
            name="output_features",
            datatype="DEFeatureClass",
            parameterType="Required",
            direction="Output")
        params.append(param7)
        
        return params

    def isLicensed(self):
        """Set whether tool is licensed to execute."""
        return True

    def updateParameters(self, parameters):
        """Modify the values and properties of parameters before internal
        validation is performed.  This method is called whenever a parameter
        has been changed."""
        return

    def updateMessages(self, parameters):
        """Modify the messages created by internal validation for each tool
        parameter.  This method is called after internal validation."""
        return

    def execute(self, parameters, messages):
        """The source code of the tool."""
        
        # Get parameters
        input_raster = parameters[0].valueAsText
        mask_layer = parameters[1].valueAsText
        workspace = parameters[2].valueAsText
        number_classes = parameters[3].value
        min_area = parameters[4].value
        buffer_distance = parameters[5].valueAsText
        min_buffer_area = parameters[6].value
        output_features = parameters[7].valueAsText
        
        # Set environment
        arcpy.env.overwriteOutput = True
        arcpy.env.workspace = workspace
        arcpy.env.cellSize = input_raster
        
        try:
            # Step 1: Extract by mask
            arcpy.AddMessage("Step 1/10: Extracting forest area from input raster...")
            raster_clipped_forest = arcpy.sa.ExtractByMask(input_raster, mask_layer)
            aerial_image = os.path.join(workspace, "aerial_image.tif")
            raster_clipped_forest.save(aerial_image)
            
            # Step 2: Iso Cluster classification
            arcpy.AddMessage("Step 2/10: Performing Iso Cluster classification...")
            out_signature_file = os.path.join(workspace, "output_signature.GSG")
            arcpy.sa.IsoCluster(aerial_image, out_signature_file, number_classes=number_classes)
            
            # Step 3: Maximum likelihood classification
            arcpy.AddMessage("Step 3/10: Performing maximum likelihood classification...")
            classified_raster = arcpy.sa.MLClassify(aerial_image, out_signature_file)
            
            # Step 4: Reclassify (keep only class 10 as dead trees)
            arcpy.AddMessage("Step 4/10: Reclassifying raster...")
            remap = arcpy.sa.RemapValue([[1, "NODATA"], [2, "NODATA"], [3, "NODATA"], 
                                       [4, "NODATA"], [5, "NODATA"], [6, "NODATA"], 
                                       [7, "NODATA"], [8, "NODATA"], [9, "NODATA"], 
                                       [10, 1]])
            out_classified_raster = arcpy.sa.Reclassify(classified_raster, "Value", remap)
            dead_trees_raster = os.path.join(workspace, "dead_trees.tif")
            out_classified_raster.save(dead_trees_raster)
            
            # Step 5: Extract by blue band
            arcpy.AddMessage("Step 5/10: Processing blue band...")
            blue_raster = os.path.join(workspace, "blue_raster.tif")
            arcpy.management.CreateColorComposite(input_raster, blue_raster, 'Band IDs', 'B3', 'B3', 'B3')
            
            blue_mask = os.path.join(workspace, "blue_mask.tif")
            remap = "29 150 NODATA; 150 250 1"
            arcpy.ddd.Reclassify(blue_raster, 'Value', remap, blue_mask, 'True')
            
            extracted_raster = os.path.join(workspace, "extracted_raster_one_band.tif")
            extracted_raster_both_bands = arcpy.sa.ExtractByMask(dead_trees_raster, blue_mask)
            extracted_raster_both_bands.save(extracted_raster)
            
            # Step 6: Filtering
            arcpy.AddMessage("Step 6/10: Applying majority filter...")
            filtered_raster = os.path.join(workspace, "filtered_raster.tif")
            (arcpy.sa.MajorityFilter(extracted_raster)).save(filtered_raster)
            
            # Step 7: Expand and shrink
            arcpy.AddMessage("Step 7/10: Expanding and shrinking to connect fragments...")
            expanded_raster = os.path.join(workspace, "expanded_raster.tif")
            (arcpy.sa.Expand(filtered_raster, 1, 1)).save(expanded_raster)
            
            shrinked_raster = os.path.join(workspace, "shrinked_raster.tif")
            (arcpy.sa.Shrink(expanded_raster, 1, 1)).save(shrinked_raster)
            
            # Step 8: Convert to vector and filter by size
            arcpy.AddMessage("Step 8/10: Converting to vector and filtering by size...")
            dead_trees_region = arcpy.sa.RegionGroup(shrinked_raster)
            
            dead_trees_vector = os.path.join(workspace, "dead_trees_vector.shp")
            arcpy.conversion.RasterToPolygon(dead_trees_region, dead_trees_vector, "NO_SIMPLIFY")
            
            arcpy.AddField_management(dead_trees_vector, "Shape_Area", "DOUBLE")
            expression = "!shape.area!"
            arcpy.CalculateField_management(dead_trees_vector, "Shape_Area", expression, "PYTHON")
            
            dead_trees_selected = os.path.join(workspace, "dead_trees_selected.shp")
            where_clause = f"Shape_Area > {min_area}"
            arcpy.analysis.Select(dead_trees_vector, dead_trees_selected, where_clause)
            
            # Step 9: Buffer and dissolve
            arcpy.AddMessage("Step 9/10: Buffering and dissolving...")
            buffered_trees = os.path.join(workspace, "buffered_trees.shp")
            arcpy.analysis.Buffer(dead_trees_selected, buffered_trees, buffer_distance, "FULL", "ROUND")
            
            dissolved_buffer = os.path.join(workspace, "dissolved_buffer.shp")
            arcpy.management.Dissolve(buffered_trees, dissolved_buffer, "", "", "SINGLE_PART")
            
            arcpy.AddField_management(dissolved_buffer, "Shape_Area", "DOUBLE")
            arcpy.CalculateField_management(dissolved_buffer, "Shape_Area", expression, "PYTHON")
            
            # Step 10: Final selection and output
            arcpy.AddMessage("Step 10/10: Creating final output...")
            trees_buffer_processed = os.path.join(workspace, "trees_buffer_processed.shp")
            where_clause = f'"Shape_Area" > {min_buffer_area}'
            arcpy.analysis.Select(dissolved_buffer, trees_buffer_processed, where_clause)
            
            # Copy to final output location
            arcpy.management.CopyFeatures(trees_buffer_processed, output_features)
            
            arcpy.AddMessage(f"Processing complete! Output saved to: {output_features}")
            
        except Exception as e:
            arcpy.AddError(f"Error occurred: {str(e)}")
            raise

        return